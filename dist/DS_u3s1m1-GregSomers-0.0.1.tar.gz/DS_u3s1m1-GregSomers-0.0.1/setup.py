from setuptools import \
    setup

setup(
    name='DS_u3s1m1-GregSomers',
    version='0.0.1',
    author='GregSomers',
    author_email='gregory-somers@lambdastudents.com',
    keywords=[
        'twitter',
        'python',
        'nlp'],
    packages=[
        'DS_u3s1m1-Twitter'],
    python_requires='>3,<4',
    install_requires='pandas')
